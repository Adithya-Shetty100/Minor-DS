#include "et.h"

Node * createExpressionTree(char* a,int len)
{
    //TODO
}


void inorder(Node *root)
{
 //TODO 
 // Note : Do not change the printf
  printf("%c",root->data); 
}

void preorder(Node *root)
{
 //TODO 
 // Note : Do not change the printf
  printf("%c",root->data);   
}

void postorder(Node *root)
{
 //TODO 
 // Note : Do not change the printf
  printf("%c",root->data); 
}

void freeTree(Node *root)
{
}

